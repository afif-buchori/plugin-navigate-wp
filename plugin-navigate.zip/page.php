<?php
require_once(dirname(__FILE__) . '/inc/function.php');
require_once(dirname(__FILE__) . '/components/input.php');
require_once(dirname(__FILE__) . '/inc/get-content.php');
require_once(dirname(__FILE__) . '/inc/header.php');

enx_get_global_page();
